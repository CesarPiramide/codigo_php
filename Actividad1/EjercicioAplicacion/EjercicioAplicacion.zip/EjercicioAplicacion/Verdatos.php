<?php
include 'platos.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Ver Platos</title>
</head>
<body>
    <h1>Listado de Platos</h1><hr>

    <?php
    foreach($platos as $id => $plato){
        echo "<h3>{$plato['nombre']} : {$plato['precio']}€</h3>";
        echo "<p>Tipo: {$plato['tipo']}</p>";
        echo "<a href='Veringredientes.php'>Ver Ingredientes</a> ";
        echo "<a href='Editar.php?id=$id'>Editar</a> ";
        echo "<a href='Borrar.php?id=$id'>Borrar</a>";
    }
    ?>

    <br><hr>
    <a href="Almacenardatos.php">Añadir nuevo plato</a>
    <br>
    <a href="index.html">Inicio</a>
</body>
</html>