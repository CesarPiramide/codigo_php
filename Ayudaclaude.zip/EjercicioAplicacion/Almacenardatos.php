<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagina sobre mi restaurante</title>
    <h2>Aqui podras introducir todo sobre los platos</h2><hr>
</head>
<body>
    <form action="logica.php" method="post">
        <label for="Nombre">Introduce el nombre del plato:</label>
        <input name="Nombre" required> <br>

    <p>Ingredientes:</p>
    <label>Huevo</label> 
    <input type="checkbox" name="ingredientes[]" value="Huevo"><br>
    <label>Patata</label>
    <input type="checkbox" name="ingredientes[]" value="Patata"><br>
    <label>Cebolla</label> 
    <input type="checkbox" name="ingredientes[]" value="Cebolla"><br>
    <label>Arroz</label>
     <input type="checkbox" name="ingredientes[]" value="Arroz"><br>
    <label>Pollo</label> 
    <input type="checkbox" name="ingredientes[]" value="Pollo"><br>
    <label>Sal</label> 
    <input type="checkbox" name="ingredientes[]" value="Sal"><br>
    <label>Tomate</label> 
    <input type="checkbox" name="ingredientes[]" value="Tomate"><br>
    <label>Ajo</label> 
    <input type="checkbox" name="ingredientes[]" value="Ajo"><br>
    <label>Leche</label> 
    <input type="checkbox" name="ingredientes[]" value="Leche"><br>
    <label>Azúcar</label> 
    <input type="checkbox" name="ingredientes[]" value="Azúcar"><br>
    <label>Harina</label> 
    <input type="checkbox" name="ingredientes[]" value="Harina"><br>
    <label>Queso</label> 
    <input type="checkbox" name="ingredientes[]" value="Queso"><br>
    <label>Jamón</label> 
    <input type="checkbox" name="ingredientes[]" value="Jamón"><br>
    <label>Pimiento</label> 
    <input type="checkbox" name="ingredientes[]" value="Pimiento"><br>
    <label>Aceite</label> 
    <input type="checkbox" name="ingredientes[]" value="Aceite"><br>

        <br>

        <label for="Tipo">Introduce si es primero/segundo/postre</label>
        <input name="Tipo" required> <br>

        <label for="Precio">Introduce el precio:</label>
        <input name="Precio" required> <br> 

        <input type="Submit">


    </form>

    <br>
    <a href="Verdatos.php">Ver platos guardados</a>
    <a href="index.html">Volver a inicio</a>
</body>
</html>

