<?php
$host = "bdwes.cnjx4wbaayua.us-east-1.rds.amazonaws.com";
$puerto = "3306";
$bd = "restaurante";
$usuario = "admin";
$clave = "Cesarjover11";

$conexion = new PDO("mysql:host=$host;port=$puerto;dbname=$bd;charset=utf8mb4", $usuario, $clave);
$conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$conexion->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
?>